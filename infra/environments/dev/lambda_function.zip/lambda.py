# -*- coding: utf-8 -*-
import boto3, os, json, base64
from requests_toolbelt.multipart import decoder
import logging
s3_client = boto3.client('s3')
bucket_name = os.environ['BUCKET_NAME']
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def push_to_s3(data, event_client):
    s3 = boto3.resource('s3')
    try:
        
        s3_key = f"{event_client}/event_{data['body'].get('messageId', 'default')}.json" 
        logger.info(f"Uploading to S3 with key: {s3_key}")
        # Save the data to S3
        try:
            s3_client.put_object(Bucket=bucket_name, Key=s3_key, Body=json.dumps(data))
        except Exception as e:
            return {
            'statusCode': 200,
            'body': json.dumps({'message': str(e)})
    } 
    except Exception as e:
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Event data saved successfully'})
    }
def process_multipart_data(body, content_type):
    """Process multipart/form-data."""
    
    multipart_data = decoder.MultipartDecoder(body, content_type)
    data = {}
    for part in multipart_data.parts:
        content_disposition = part.headers[b'Content-Disposition'].decode()
        content_type_part = part.headers.get(b'Content-Type', b'').decode()
        if 'application/json' in content_type_part:
            logger.info(f"Part content: {part.text}")
            data = json.loads(part.text)
    return data
    

def process_event(event):
        logger.info(f"Processing event: {json.dumps(event)}")
    # we should process event at this stage
        headers = event.get('headers', {})
        if 'x-settings' not in headers:
            return {
                'statusCode': 400,  
                'body': json.dumps({'error': 'x-settings is not in headers'})
            }

        client_name = headers['x-settings']
        
        # Decode multipart form data
        content_type = headers.get('Content-Type')
        if event['isBase64Encoded']:
            logger.info("Decoding base64-encoded body")
            body = base64.b64decode(event['body'])
        else:
            body = event['body']
            body = base64.b64decode(event["body"])
            
        try:
            data = process_multipart_data(body, content_type)
            logger.info(f"Processed data: {json.dumps(data)}")
            return  push_to_s3(data, client_name)
        except Exception as e:
            return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
       
def lambda_handler(event, context):
    try:
        response = process_event(event)
        return response
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }